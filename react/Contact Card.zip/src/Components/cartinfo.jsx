export default function Cinfo(props){
    return(
      <tr> 
       <td>{props.pname}</td>
       <td>{props.price}</td>
       <td>{props.quantity}</td>
      </tr>
    )
} 