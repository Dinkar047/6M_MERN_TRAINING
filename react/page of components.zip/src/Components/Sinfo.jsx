export default function Sinfo(props){
    return(
      <tr> 
       <td>{props.sname}</td>
       <td>{props.course}</td>
       </tr>
    )
} 