export default function Info(props){
    return(
      <tbody> 
       <td>{props.ename}</td>
       <td>{props.department}</td>
       <td>{props.type}</td>
      </tbody>
    )
}