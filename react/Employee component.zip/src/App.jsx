import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'

import Employee from './assets/Components/employee'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Employee/>
      <Employee/>
      <Employee/>
    </>
  )
}

export default App
