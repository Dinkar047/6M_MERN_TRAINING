export default function Info(props){
    return(
      <tr> 
       <td>{props.ename}</td>
       <td>{props.department}</td>
       <td>{props.type}</td>
      </tr>
    )
}